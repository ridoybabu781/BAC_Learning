import { HouseIcon } from "@phosphor-icons/react";
import React from "react";

export default function ShoppingCart() {
  return <div>ShoppingCart</div>;
}
