import { CaretRightIcon, HouseIcon } from "@phosphor-icons/react";
import React from "react";

export default function Wishlist() {
  return <div>Wishlist</div>;
}
