

//this file is added to have tailwind intelligence support. 
//it is needs no longer to use this file to config tailwind css 